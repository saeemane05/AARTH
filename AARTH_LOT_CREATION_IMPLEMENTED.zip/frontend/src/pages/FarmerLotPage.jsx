import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";

import { authApi, locationApi, lotApi } from "../api/auth";
import { FARMER_CROP_CATEGORIES } from "../data/farmerCropMaster";
import { MAHARASHTRA_DISTRICTS } from "../data/maharashtraLocations";
import logo from "../assets/aarth-logo.png";
import "./FarmerLotPage.css";

const ALL_CROPS = Object.entries(FARMER_CROP_CATEGORIES).flatMap(([category, crops]) =>
  crops.map((crop) => ({ ...crop, category }))
);

const CROP_QUALITY = {
  onion: {
    grades: ["Grade A", "Grade B", "Grade C", "Not sure / To be verified"],
    sizes: ["<45 mm", "45–55 mm", "55–70 mm", ">70 mm"],
    measurements: [
      ["moisture_percent", "Moisture", "%", "Optional if known"],
      ["damage_percent", "Visible damage", "%", "Optional if known"],
      ["foreign_matter_percent", "Foreign matter", "%", "Optional if known"],
    ],
  },
  soybean: {
    grades: ["Grade A", "Grade B", "FAQ / Standard", "Not sure / To be verified"],
    measurements: [
      ["moisture_percent", "Moisture", "%", "Optional if known"],
      ["foreign_matter_percent", "Foreign matter", "%", "Optional if known"],
      ["damaged_grains_percent", "Damaged grains", "%", "Optional if known"],
    ],
  },
  wheat: {
    grades: ["FAQ / Standard", "Grade A", "Grade B", "Not sure / To be verified"],
    measurements: [
      ["moisture_percent", "Moisture", "%", "Optional if known"],
      ["foreign_matter_percent", "Foreign matter", "%", "Optional if known"],
    ],
  },
  grapes: {
    grades: ["Export grade", "Domestic Grade A", "Domestic Grade B", "Not sure / To be verified"],
    sizes: ["Small", "Medium", "Large", "Mixed"],
    measurements: [
      ["brix", "Brix", "°Bx", "Optional if known"],
      ["damage_percent", "Visible damage", "%", "Optional if known"],
    ],
  },
};

const STEPS = [
  ["Produce", "What are you selling?"],
  ["Quantity", "How much do you have?"],
  ["Quality", "What is the quality?"],
  ["Location & timing", "Where and when is it available?"],
  ["Selling terms", "How would you like to sell?"],
  ["Review", "Check before creating"],
];

const INITIAL = {
  commodity_key: "",
  commodity_name: "",
  variety: "",
  quantity: "",
  quantity_unit: "quintal",
  partial_sale_allowed: false,
  minimum_sale_quantity: "",
  harvest_date: "",
  grade: "",
  size_calibre: "",
  quality_measurements: {},
  pickup_district: "",
  pickup_taluka: "",
  pickup_village: "",
  pickup_location_text: "",
  pickup_latitude: null,
  pickup_longitude: null,
  location_source: "MANUAL_SEARCH",
  location_verified: false,
  location_verified_at: null,
  location_accuracy_m: null,
  available_from: "",
  pickup_until: "",
  expected_price: "",
  price_negotiable: true,
  payment_needed_by: "",
  open_to_aggregation: false,
};

function today() {
  return new Date().toISOString().slice(0, 10);
}

function formatDate(value) {
  if (!value) return "—";
  return new Date(`${value}T00:00:00`).toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

function formatQuantity(value, unit) {
  if (value === null || value === undefined || value === "") return "—";
  return `${Number(value).toLocaleString("en-IN")} ${unit}`;
}

function qualityFor(commodityKey) {
  return CROP_QUALITY[commodityKey] || {
    grades: ["Standard / FAQ", "Grade A", "Grade B", "Not sure / To be verified"],
    sizes: [],
    measurements: [],
  };
}

export default function FarmerLotPage({ mode = "create" }) {
  const navigate = useNavigate();
  const [session, setSession] = useState(() => authApi.getSession());
  const [profile, setProfile] = useState(() => authApi.getSession()?.profile || {});
  const [form, setForm] = useState(INITIAL);
  const [step, setStep] = useState(0);
  const [attempted, setAttempted] = useState([]);
  const [cropScope, setCropScope] = useState("profile");
  const [cropSearch, setCropSearch] = useState("");
  const [locationSearch, setLocationSearch] = useState("");
  const [suggestions, setSuggestions] = useState([]);
  const [locationLoading, setLocationLoading] = useState(false);
  const [locationNotice, setLocationNotice] = useState("");
  const [saving, setSaving] = useState(false);
  const [lots, setLots] = useState([]);
  const [loadingLots, setLoadingLots] = useState(mode === "list");
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");

  const profileCrops = useMemo(() => {
    const selected = Array.isArray(profile?.profile_data?.crops_grown)
      ? profile.profile_data.crops_grown
      : [];
    return ALL_CROPS.filter((crop) => selected.includes(crop.key));
  }, [profile]);

  const visibleCrops = useMemo(() => {
    const base = cropScope === "profile" ? profileCrops : ALL_CROPS;
    const query = cropSearch.trim().toLowerCase();
    if (!query) return base;
    return base.filter((crop) =>
      `${crop.name} ${crop.key} ${crop.code} ${crop.category}`.toLowerCase().includes(query)
    );
  }, [cropScope, cropSearch, profileCrops]);

  const quality = qualityFor(form.commodity_key);

  useEffect(() => {
    let active = true;
    authApi.me().then((nextProfile) => {
      if (!active) return;
      setProfile(nextProfile);
      setSession((current) => ({ ...(current || {}), profile: nextProfile }));
      const profileData = nextProfile?.profile_data || {};
      setForm((current) => ({
        ...current,
        pickup_district: current.pickup_district || profileData.district || "",
        pickup_taluka: current.pickup_taluka || profileData.taluka || "",
        pickup_village: current.pickup_village || profileData.village || "",
      }));
    }).catch(() => navigate("/login", { replace: true }));
    return () => { active = false; };
  }, [navigate]);

  useEffect(() => {
    if (mode !== "list") return;
    let active = true;
    setLoadingLots(true);
    lotApi.list().then((response) => {
      if (active) setLots(response?.lots || []);
    }).catch((err) => {
      if (active) setError(err.message || "Unable to load your lots.");
    }).finally(() => {
      if (active) setLoadingLots(false);
    });
    return () => { active = false; };
  }, [mode]);

  // Try the device's current location once. If permission is denied or unavailable,
  // the farmer can continue with manual map-search and must select a verified result.
  useEffect(() => {
    if (mode !== "create" || !navigator.geolocation || form.location_verified) return;
    navigator.geolocation.getCurrentPosition(
      async (position) => {
        try {
          setLocationLoading(true);
          const result = await locationApi.reverse(position.coords.latitude, position.coords.longitude);
          setForm((current) => ({
            ...current,
            pickup_district: result.district || current.pickup_district,
            pickup_taluka: result.taluka || current.pickup_taluka,
            pickup_village: result.village || current.pickup_village,
            pickup_location_text: result.display_name,
            pickup_latitude: result.latitude,
            pickup_longitude: result.longitude,
            location_source: "CURRENT_DEVICE",
            location_verified: Boolean(result.verified),
            location_verified_at: new Date().toISOString(),
            location_accuracy_m: position.coords.accuracy,
          }));
          setLocationNotice("Current device location found and verified on the Maharashtra map.");
        } catch {
          setLocationNotice("Current location could not be verified. You can search for the pickup location manually.");
        } finally {
          setLocationLoading(false);
        }
      },
      () => setLocationNotice("Location permission was not available. Use manual location search below."),
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 120000 },
    );
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode]);

  useEffect(() => {
    const query = locationSearch.trim();
    if (query.length < 2 || form.location_verified) {
      setSuggestions([]);
      return undefined;
    }
    const timer = window.setTimeout(async () => {
      try {
        setLocationLoading(true);
        const response = await locationApi.search(query, form.pickup_district, form.pickup_taluka);
        setSuggestions(response?.suggestions || []);
      } catch {
        setSuggestions([]);
      } finally {
        setLocationLoading(false);
      }
    }, 350);
    return () => window.clearTimeout(timer);
  }, [locationSearch, form.pickup_district, form.pickup_taluka, form.location_verified]);

  function update(key, value) {
    setForm((current) => {
      const next = { ...current, [key]: value };
      if (["pickup_district", "pickup_taluka", "pickup_village"].includes(key)) {
        next.location_verified = false;
        next.location_verified_at = null;
        next.pickup_latitude = null;
        next.pickup_longitude = null;
        next.location_accuracy_m = null;
        next.location_source = "MANUAL_SEARCH";
      }
      return next;
    });
    setError("");
  }

  function selectCrop(crop) {
    setForm((current) => ({
      ...current,
      commodity_key: crop.key,
      commodity_name: crop.name,
      variety: "",
      grade: "",
      size_calibre: "",
      quality_measurements: {},
    }));
    setError("");
  }

  function updateQuality(key, value) {
    setForm((current) => ({
      ...current,
      quality_measurements: { ...current.quality_measurements, [key]: value },
    }));
  }

  function useCurrentLocation() {
    if (!navigator.geolocation) {
      setLocationNotice("This browser does not provide device location. Search manually instead.");
      return;
    }
    setLocationLoading(true);
    setLocationNotice("Getting your current location…");
    navigator.geolocation.getCurrentPosition(async (position) => {
      try {
        const result = await locationApi.reverse(position.coords.latitude, position.coords.longitude);
        updateLocationFromResult(result, "CURRENT_DEVICE");
        setLocationNotice("Current device location found and verified on the Maharashtra map.");
      } catch (err) {
        setLocationNotice(err.message || "Could not verify current location.");
      } finally {
        setLocationLoading(false);
      }
    }, () => {
      setLocationLoading(false);
      setLocationNotice("Location permission was denied or unavailable. Search manually instead.");
    }, { enableHighAccuracy: true, timeout: 10000, maximumAge: 120000 });
  }

  async function updateLocationFromResult(result, source = "MANUAL_SEARCH") {
    try {
      setLocationLoading(true);
      const verified = await locationApi.reverse(result.latitude, result.longitude);
      setForm((current) => ({
        ...current,
        pickup_district: verified.district || result.district || current.pickup_district,
        pickup_taluka: verified.taluka || result.taluka || current.pickup_taluka,
        pickup_village: verified.village || result.village || current.pickup_village,
        pickup_location_text: verified.display_name || result.display_name,
        pickup_latitude: verified.latitude,
        pickup_longitude: verified.longitude,
        location_source: source,
        location_verified: Boolean(verified.verified),
        location_verified_at: new Date().toISOString(),
        location_accuracy_m: null,
      }));
      setLocationSearch(verified.display_name || result.display_name || "");
      setLocationNotice("Selected pickup location was re-checked against the map service.");
      setSuggestions([]);
    } catch (err) {
      setLocationNotice(err.message || "Could not verify the selected location.");
    } finally {
      setLocationLoading(false);
    }
  }

  function clearLocation() {
    setForm((current) => ({
      ...current,
      pickup_location_text: "",
      pickup_latitude: null,
      pickup_longitude: null,
      location_verified: false,
      location_verified_at: null,
      location_accuracy_m: null,
      location_source: "MANUAL_SEARCH",
    }));
    setLocationSearch("");
    setLocationNotice("");
  }

  function stepComplete(index) {
    if (index === 0) return Boolean(form.commodity_key && form.commodity_name);
    if (index === 1) return Number(form.quantity) > 0 && (!form.partial_sale_allowed || Number(form.minimum_sale_quantity) > 0);
    if (index === 2) return Boolean(form.grade);
    if (index === 3) return Boolean(form.pickup_district && form.pickup_village && form.pickup_location_text && form.location_verified && form.available_from && form.pickup_until && form.payment_needed_by);
    if (index === 4) return Number(form.expected_price) >= 0 && form.expected_price !== "";
    return [0, 1, 2, 3, 4].every(stepComplete);
  }

  function next() {
    if (!stepComplete(step)) {
      setAttempted((current) => [...new Set([...current, step])]);
      setError("Please complete the required information in this section before continuing.");
      return;
    }
    setError("");
    setStep((current) => Math.min(current + 1, STEPS.length - 1));
  }

  function back() {
    setError("");
    setStep((current) => Math.max(current - 1, 0));
  }

  async function createLot() {
    if (!stepComplete(4)) {
      setAttempted((current) => [...new Set([...current, 4])]);
      setError("Please complete the selling terms.");
      return;
    }
    setSaving(true);
    setError("");
    try {
      const response = await lotApi.create({
        ...form,
        quantity: Number(form.quantity),
        minimum_sale_quantity: form.partial_sale_allowed ? Number(form.minimum_sale_quantity) : null,
        expected_price: Number(form.expected_price),
        quality_measurements: Object.fromEntries(
          Object.entries(form.quality_measurements || {}).filter(([, value]) => value !== "")
        ),
        status: "ACTIVE",
      });
      localStorage.removeItem("aarth_lot_incomplete");
      navigate("/farmer/lots", { state: { createdLot: response } });
    } catch (err) {
      setError(err.message || "Could not create the lot.");
    } finally {
      setSaving(false);
    }
  }

  function logout() {
    authApi.logout();
    navigate("/login", { replace: true });
  }

  const displayName = profile?.profile_data?.full_name || profile?.username || "Farmer";

  if (mode === "list") {
    return (
      <div className="lot-page-shell">
        <LotTopbar displayName={displayName} active="My Lots" onLogout={logout} onNavigate={navigate} />
        <main className="lot-main">
          <div className="lot-page-heading">
            <div>
              <span className="lot-eyebrow">FARMER · SUPPLY</span>
              <h1>My Lots</h1>
              <p>Review the produce lots you have created. Verified location and farmer-declared quality remain clearly separated from later verification.</p>
            </div>
            <button className="lot-primary-button" onClick={() => navigate("/farmer/lots/new")}><b>＋</b> Create new lot</button>
          </div>
          {notice && <div className="lot-success">✓ {notice}</div>}
          {error && <div className="lot-error">{error}</div>}
          <section className="lot-table-card">
            <div className="lot-table-head"><div><h2>Lot review</h2><p>{lots.length} lot{lots.length === 1 ? "" : "s"} on your account</p></div><span className="lot-trust-note">● Farmer account protected</span></div>
            {loadingLots ? <div className="lot-empty">Loading your lots…</div> : lots.length === 0 ? (
              <div className="lot-empty"><div className="lot-empty-icon">◇</div><h3>No lots created yet</h3><p>Create your first lot and AARTH will use it for market, buyer, aggregation and economic matching.</p><button className="lot-primary-button" onClick={() => navigate("/farmer/lots/new")}>Create your first lot</button></div>
            ) : (
              <div className="lot-table-wrap"><table className="lot-table"><thead><tr><th>Lot</th><th>Produce</th><th>Quantity</th><th>Quality</th><th>Pickup location</th><th>Available</th><th>Expected price</th><th>Status</th></tr></thead><tbody>{lots.map((lot) => <tr key={lot.lot_id}><td><strong>{lot.lot_id}</strong><small>{formatDate(lot.created_at?.slice(0, 10))}</small></td><td><strong>{lot.commodity_name}</strong><small>{lot.variety || "Variety not specified"}</small></td><td>{formatQuantity(lot.quantity, lot.quantity_unit)}</td><td><span className="table-grade">{lot.grade || "—"}</span><small>{lot.size_calibre || "Size not specified"}</small></td><td><strong>{lot.pickup_village}</strong><small>{[lot.pickup_taluka, lot.pickup_district].filter(Boolean).join(", ")}</small>{lot.location_verified && <span className="verified-pill">✓ Location verified</span>}</td><td>{formatDate(lot.available_from)}<small>until {formatDate(lot.pickup_until)}</small></td><td>₹{Number(lot.expected_price).toLocaleString("en-IN")}<small>/ quintal</small></td><td><span className={`lot-status ${String(lot.status).toLowerCase()}`}>{lot.status}</span></td></tr>)}</tbody></table></div>
            )}
          </section>
        </main>
      </div>
    );
  }

  return (
    <div className="lot-page-shell">
      <LotTopbar displayName={displayName} active="Create Lot" onLogout={logout} onNavigate={navigate} />
      <main className="lot-main">
        <div className="lot-page-heading">
          <div><span className="lot-eyebrow">AARTH · FARMER LOT</span><h1>Create a new lot</h1><p>Tell AARTH about the produce you are ready to sell. We keep the form short and use the information later for buyer matching, aggregation and true transaction economics.</p></div>
          <button className="lot-secondary-button" onClick={() => navigate("/farmer/lots")}>◇ My lots</button>
        </div>

        <div className="lot-layout">
          <section className="lot-form-card">
            <div className="lot-stepper">{STEPS.map(([title], index) => { const complete = stepComplete(index); const incomplete = attempted.includes(index) && !complete; return <button key={title} className={[index === step ? "current" : "", complete ? "completed" : "", incomplete ? "incomplete" : ""].filter(Boolean).join(" ")} onClick={() => { if (index <= step || stepComplete(step)) setStep(index); else setAttempted((current) => [...new Set([...current, step])]); }}><i>{complete ? "✓" : index + 1}</i><span>{title}</span></button>; })}</div>

            <div className="lot-form-body">
              {step === 0 && <ProduceStep profileCrops={profileCrops} allCrops={visibleCrops} cropScope={cropScope} setCropScope={setCropScope} cropSearch={cropSearch} setCropSearch={setCropSearch} selected={form.commodity_key} onSelect={selectCrop} form={form} update={update} />}
              {step === 1 && <QuantityStep form={form} update={update} />}
              {step === 2 && <QualityStep form={form} update={update} updateQuality={updateQuality} quality={quality} />}
              {step === 3 && <LocationStep form={form} update={update} updateLocation={updateLocationFromResult} clearLocation={clearLocation} locationSearch={locationSearch} setLocationSearch={setLocationSearch} suggestions={suggestions} locationLoading={locationLoading} locationNotice={locationNotice} useCurrentLocation={useCurrentLocation} />}
              {step === 4 && <SellingStep form={form} update={update} />}
              {step === 5 && <ReviewStep form={form} quality={quality} onEdit={setStep} profile={profile} />}
            </div>

            {error && <div className="lot-error form-error">{error}</div>}
            <footer className="lot-form-footer">
              {step > 0 ? <button className="lot-secondary-button" onClick={back}>← Back</button> : <span />}
              {step < 5 ? <button className="lot-primary-button" onClick={next}>Continue <b>→</b></button> : <button className="lot-primary-button" disabled={saving} onClick={createLot}>{saving ? "Creating lot…" : "Create lot"}</button>}
            </footer>
          </section>

          <aside className="lot-aside">
            <section className="lot-readiness-card"><div className="lot-aside-title"><span>LOT READINESS</span><strong>{Math.round(([0,1,2,3,4].filter(stepComplete).length / 5) * 100)}%</strong></div><div className="lot-progress"><span style={{ width: `${Math.round(([0,1,2,3,4].filter(stepComplete).length / 5) * 100)}%` }} /></div><p>{[0,1,2,3,4].filter(stepComplete).length} of 5 required sections completed.</p></section>
            <section className="lot-trust-card"><div className="lot-trust-icon">✓</div><div><strong>Clear information sources</strong><p>Your pickup pin is map-verified. Quality remains farmer-declared until an assayer or buyer verifies it.</p></div></section>
            <section className="lot-smart-card"><span>☘</span><div><strong>Why AARTH asks this</strong><p>Quantity, quality, location, timing and selling constraints become inputs for buyer matching, multi-lot aggregation and landed-cost comparison.</p></div></section>
          </aside>
        </div>
      </main>
    </div>
  );
}

function LotTopbar({ displayName, active, onLogout, onNavigate }) {
  return <header className="lot-topbar"><button className="lot-brand" onClick={() => onNavigate("/farmer")}><img src={logo} alt="AARTH" /><span><strong>AARTH</strong><small>FARMERS · MARKETS · OPPORTUNITIES</small></span></button><nav><button className={active === "Profile" ? "active" : ""} onClick={() => onNavigate("/farmer")}>● <span>Profile</span></button><button className={active === "Create Lot" ? "active" : ""} onClick={() => onNavigate("/farmer/lots/new")}>＋ <span>Create Lot</span></button><button className={active === "My Lots" ? "active" : ""} onClick={() => onNavigate("/farmer/lots")}>◇ <span>My Lots</span></button><button onClick={() => onNavigate("/farmer")}>▥ <span>Market Insights</span></button><button onClick={() => onNavigate("/farmer")}>♧ <span>Buyers</span></button></nav><div className="lot-account"><span className="lot-avatar">{displayName.slice(0,2).toUpperCase()}</span><div><strong>{displayName}</strong><small>Farmer</small></div><button onClick={onLogout}>↪</button></div></header>;
}

function ProduceStep({ profileCrops, allCrops, cropScope, setCropScope, cropSearch, setCropSearch, selected, onSelect, form, update }) {
  return <div><SectionTitle icon="☘" title="What are you selling?" text="Choose a crop from your farmer profile, or search the full AARTH crop master for another crop." />
    <div className="lot-source-tabs"><button className={cropScope === "profile" ? "active" : ""} onClick={() => setCropScope("profile")}>My profile crops <span>{profileCrops.length}</span></button><button className={cropScope === "all" ? "active" : ""} onClick={() => setCropScope("all")}>Choose another crop</button></div>
    <label className="lot-field wide"><span>Crop / commodity <sup>*</sup></span><div className="lot-search"><b>⌕</b><input value={cropSearch} onChange={(e) => setCropSearch(e.target.value)} placeholder="Search crop name…" /></div></label>
    <div className="crop-choice-grid">{allCrops.length ? allCrops.map((crop) => <button type="button" key={crop.key} className={selected === crop.key ? "selected" : ""} onClick={() => onSelect(crop)}><i>{selected === crop.key ? "✓" : "☘"}</i><span><strong>{crop.name}</strong><small>{crop.category}</small></span></button>) : <div className="crop-empty">No crops found in this view. Try “Choose another crop”.</div>}</div>
    {form.commodity_key && <div className="selected-crop-card"><span>Selected</span><strong>{form.commodity_name}</strong><small>{form.commodity_key}</small></div>}
    <div className="lot-field-grid"><label className="lot-field"><span>Variety <em>Optional</em></span><input value={form.variety} onChange={(e) => update("variety", e.target.value)} placeholder="e.g. N-2, Sonaka…" /><small>If the variety is not known, you can leave this blank.</small></label><label className="lot-field"><span>Harvest date <sup>*</sup></span><input type="date" max={today()} value={form.harvest_date} onChange={(e) => update("harvest_date", e.target.value)} /></label></div>
  </div>;
}

function QuantityStep({ form, update }) {
  return <div><SectionTitle icon="▣" title="How much do you have?" text="Enter the quantity that is actually available for this lot. AARTH standardizes units internally for matching." /><div className="lot-field-grid"><label className="lot-field"><span>Available quantity <sup>*</sup></span><input type="number" min="0.001" step="0.001" value={form.quantity} onChange={(e) => update("quantity", e.target.value)} placeholder="e.g. 50" /></label><label className="lot-field"><span>Unit <sup>*</sup></span><select value={form.quantity_unit} onChange={(e) => update("quantity_unit", e.target.value)}><option value="kg">Kilogram (kg)</option><option value="quintal">Quintal (qtl)</option><option value="ton">Tonne (MT)</option></select></label></div><div className="lot-choice-card"><div><strong>Can you sell only part of this lot?</strong><small>This helps AARTH match your produce with buyers who need smaller quantities.</small></div><div className="segmented"><button className={!form.partial_sale_allowed ? "active" : ""} onClick={() => { update("partial_sale_allowed", false); update("minimum_sale_quantity", ""); }}>Entire lot only</button><button className={form.partial_sale_allowed ? "active" : ""} onClick={() => update("partial_sale_allowed", true)}>Part of lot is okay</button></div></div>{form.partial_sale_allowed && <label className="lot-field"><span>Minimum quantity you are willing to sell <sup>*</sup></span><div className="input-with-unit"><input type="number" min="0.001" step="0.001" value={form.minimum_sale_quantity} onChange={(e) => update("minimum_sale_quantity", e.target.value)} placeholder="e.g. 10" /><b>{form.quantity_unit}</b></div></label>}</div>;
}

function QualityStep({ form, update, updateQuality, quality }) {
  return <div><SectionTitle icon="◈" title="What is the quality?" text="Choose the grade you believe describes the lot. Technical measurements are optional unless you already know them." /><div className="quality-source-note"><span>i</span><p><strong>Farmer declaration</strong><br />This is not a certification. AARTH can attach assayer or buyer verification later.</p></div><div className="lot-field-grid"><label className="lot-field"><span>Basic quality / grade <sup>*</sup></span><select value={form.grade} onChange={(e) => update("grade", e.target.value)}><option value="">Select grade</option>{quality.grades.map((grade) => <option key={grade}>{grade}</option>)}</select></label>{quality.sizes.length > 0 && <label className="lot-field"><span>Size / calibre <em>Optional</em></span><select value={form.size_calibre} onChange={(e) => update("size_calibre", e.target.value)}><option value="">Select size</option>{quality.sizes.map((size) => <option key={size}>{size}</option>)}</select></label>}</div>{quality.measurements.length > 0 && <div className="measurement-panel"><div><strong>Additional quality information</strong><small>Only fill values you know. Leave unknown values blank.</small></div><div className="lot-field-grid">{quality.measurements.map(([key, label, unit, hint]) => <label className="lot-field" key={key}><span>{label} <em>{unit}</em></span><div className="input-with-unit"><input type="number" min="0" step="0.01" value={form.quality_measurements?.[key] || ""} onChange={(e) => updateQuality(key, e.target.value)} placeholder="Not provided" /><b>{unit}</b></div><small>{hint}</small></label>)}</div></div>}<label className="evidence-toggle"><input type="checkbox" checked={Array.isArray(form.evidence) && form.evidence.length > 0} onChange={() => {}} disabled /><span>Photos/evidence will be added in the next evidence step of AARTH.</span></label></div>;
}

function LocationStep({ form, update, updateLocation, clearLocation, locationSearch, setLocationSearch, suggestions, locationLoading, locationNotice, useCurrentLocation }) {
  return <div><SectionTitle icon="⌖" title="Where and when is the lot available?" text="AARTH uses the pickup point for distance, logistics and nearby-lot calculations. Your exact home address is not required." /><div className="location-action-row"><button className="location-current-button" onClick={useCurrentLocation}>⌖ {locationLoading ? "Checking location…" : "Use current location"}</button>{form.location_verified && <span className="verified-location"><b>✓</b> Location verified</span>}</div>{locationNotice && <div className="location-notice">{locationNotice}</div>}<label className="lot-field wide"><span>Search pickup location <sup>*</sup></span><div className="lot-search"><b>⌕</b><input value={locationSearch} onChange={(e) => { setLocationSearch(e.target.value); if (form.location_verified) clearLocation(); }} placeholder="Search village, market, collection centre or area…" /></div><small>Suggestions are map locations in Maharashtra. Select one to save its verified coordinates.</small>{suggestions.length > 0 && <div className="location-suggestions">{suggestions.map((item, index) => <button type="button" key={`${item.display_name}-${index}`} onClick={() => updateLocation(item, "MANUAL_SEARCH")}><span>⌖</span><div><strong>{item.display_name}</strong><small>{[item.village, item.taluka, item.district].filter(Boolean).join(" · ")}</small></div></button>)}</div>}</label>{form.location_verified && <div className="selected-location-card"><div className="selected-location-pin">⌖</div><div><strong>{form.pickup_location_text}</strong><small>{[form.pickup_village, form.pickup_taluka, form.pickup_district].filter(Boolean).join(", ")}</small><span>Coordinates verified by map service · {Number(form.pickup_latitude).toFixed(5)}, {Number(form.pickup_longitude).toFixed(5)}{form.location_accuracy_m ? ` · device accuracy ~${Math.round(form.location_accuracy_m)} m` : ""}</span></div><button onClick={clearLocation}>Change</button></div>}<div className="lot-field-grid"><label className="lot-field"><span>District <sup>*</sup></span><select value={form.pickup_district} onChange={(e) => update("pickup_district", e.target.value)}>{<option value="">Select district</option>}{MAHARASHTRA_DISTRICTS.map((district) => <option key={district.name}>{district.name}</option>)}</select></label><label className="lot-field"><span>Village <sup>*</sup></span><input value={form.pickup_village} onChange={(e) => update("pickup_village", e.target.value)} placeholder="Village / locality" /></label></div><div className="lot-field-grid"><label className="lot-field"><span>Available from <sup>*</sup></span><input type="date" min={today()} value={form.available_from} onChange={(e) => update("available_from", e.target.value)} /></label><label className="lot-field"><span>Latest pickup date <sup>*</sup></span><input type="date" min={form.available_from || today()} value={form.pickup_until} onChange={(e) => update("pickup_until", e.target.value)} /></label></div><label className="lot-field"><span>When do you need the sale proceeds? <sup>*</sup></span><select value={form.payment_needed_by} onChange={(e) => update("payment_needed_by", e.target.value)}><option value="">Select timing</option><option value={today()}>Today</option><option value={new Date(Date.now() + 2 * 86400000).toISOString().slice(0,10)}>Within 2 days</option><option value={new Date(Date.now() + 7 * 86400000).toISOString().slice(0,10)}>Within 7 days</option><option value="2099-12-31">No specific deadline</option></select><small>This is specific to this lot, not a permanent farmer-profile preference.</small></label></div>;
}

function SellingStep({ form, update }) {
  return <div><SectionTitle icon="₹" title="How would you like to sell?" text="Your expected price is an input for negotiation, not a guaranteed market price. AARTH will compare it with market context later." /><label className="lot-field"><span>Expected price <sup>*</sup></span><div className="input-with-unit"><span className="rupee-prefix">₹</span><input type="number" min="0" step="0.01" value={form.expected_price} onChange={(e) => update("expected_price", e.target.value)} placeholder="e.g. 2700" /><b>per quintal</b></div><small>Enter the price you expect to receive. AARTH will keep market-reference prices separate.</small></label><div className="lot-choice-card"><div><strong>Is the expected price negotiable?</strong><small>Buyers may make offers or counteroffers later.</small></div><div className="segmented"><button className={form.price_negotiable ? "active" : ""} onClick={() => update("price_negotiable", true)}>Yes</button><button className={!form.price_negotiable ? "active" : ""} onClick={() => update("price_negotiable", false)}>No</button></div></div><div className="lot-choice-card"><div><strong>Are you open to combining this lot with other farmers?</strong><small>AARTH will calculate whether aggregation is actually feasible and useful; saying yes does not commit you to a buyer.</small></div><div className="segmented"><button className={form.open_to_aggregation ? "active" : ""} onClick={() => update("open_to_aggregation", true)}>Yes, open to it</button><button className={!form.open_to_aggregation ? "active" : ""} onClick={() => update("open_to_aggregation", false)}>No</button></div></div><div className="lot-choice-card"><div><strong>Can buyers take only part of this lot?</strong><small>This follows your quantity setting and is shown here for confirmation.</small></div><span className="read-only-choice">{form.partial_sale_allowed ? "Part of lot allowed" : "Entire lot only"}</span></div></div>;
}

function ReviewStep({ form, quality, onEdit, profile }) {
  return <div><SectionTitle icon="✓" title="Review your lot" text="Check the information before creating the lot. Farmer-declared information is clearly marked; map location is verified." /><div className="review-table-wrap"><table className="lot-review-table"><tbody><tr><th>Produce</th><td><strong>{form.commodity_name || "—"}</strong><br /><small>{form.variety || "Variety not specified"}</small></td><th>Quantity</th><td>{formatQuantity(form.quantity, form.quantity_unit)}</td></tr><tr><th>Harvest</th><td>{formatDate(form.harvest_date)}</td><th>Quality</th><td><strong>{form.grade}</strong>{form.size_calibre && <><br /><small>{form.size_calibre}</small></>}</td></tr><tr><th>Pickup</th><td colSpan="3"><strong>{form.pickup_location_text}</strong><br /><small>{[form.pickup_village, form.pickup_taluka, form.pickup_district].filter(Boolean).join(", ")} · <span className="verified-text">✓ map verified</span></small></td></tr><tr><th>Availability</th><td>{formatDate(form.available_from)} – {formatDate(form.pickup_until)}</td><th>Payment needed</th><td>{form.payment_needed_by === "2099-12-31" ? "No specific deadline" : formatDate(form.payment_needed_by)}</td></tr><tr><th>Expected price</th><td>₹{Number(form.expected_price || 0).toLocaleString("en-IN")} / quintal</td><th>Negotiable</th><td>{form.price_negotiable ? "Yes" : "No"}</td></tr><tr><th>Aggregation</th><td>{form.open_to_aggregation ? "Open to aggregation" : "Individual sale"}</td><th>Partial sale</th><td>{form.partial_sale_allowed ? `Yes · minimum ${form.minimum_sale_quantity} ${form.quantity_unit}` : "No"}</td></tr></tbody></table></div><div className="review-source-grid"><div><span>DECLARATION</span><strong>{profile?.profile_data?.full_name || profile?.username || "Farmer"}</strong><small>Farmer-entered lot information</small></div><div><span>LOCATION</span><strong>Verified</strong><small>Coordinates confirmed by map geocoding</small></div><div><span>QUALITY</span><strong>{form.grade}</strong><small>Farmer declared · verification can be added later</small></div></div><button className="review-edit-note" onClick={() => onEdit(2)}>Need to change quality or details? Edit the relevant section.</button></div>;
}

function SectionTitle({ icon, title, text }) {
  return <div className="lot-section-title"><span>{icon}</span><div><h2>{title}</h2><p>{text}</p></div></div>;
}
