import RoleProfileDashboard from "./RoleProfileDashboard";

import {
  MAHARASHTRA_DISTRICTS,
  MAHARASHTRA_TALUKAS,
} from "../data/maharashtraLocations";

import {
  FARMER_CROP_CATEGORIES,
} from "../data/farmerCropMaster";


const farmerConfig = {
  slug: "farmer",

  role: "FARMER",
  roleLabel: "FARMER",

  welcome: "Farmer",

  /* A softer teal instead of the previous dark green. */
  accent: "#159c91",
  deep: "#0b5d58",
  soft: "#e9f7f5",

  icon: "🌿",

  tagline: [
    "Farmers",
    "Markets",
    "Opportunities",
  ],

  subtitle:
    "Build your farmer profile to connect with relevant AARTH opportunities.",

  formDescription:
    "Tell us about yourself and your farm. This profile is visible to relevant AARTH participants and helps them understand your agricultural background before you create a lot.",

  sectionTitle: "Basic Information",
  sectionIcon: "👨‍🌾",

  steps: [
    "Personal & Location",
    "Farm Profile",
    "Review & Publish",
  ],

  nameFields: ["full_name"],

  nav: [
    { label: "Home", icon: "home" },
    { label: "Profile", icon: "user" },
    { label: "Market Insights", icon: "chart" },
    { label: "Create Lot", icon: "plus" },
    { label: "My Lots", icon: "box" },
    { label: "Buyers", icon: "users" },
    { label: "Advisories", icon: "book" },
    { label: "Weather", icon: "cloud" },
    { label: "Support", icon: "headset" },
  ],

  fields: [

    /* =====================================================
       STEP 1 — PROFILE DETAILS
       These are stable identity/location fields.
    ====================================================== */

    {
      key: "full_name",
      label: "Full name",
      placeholder: "Enter your full name",
      required: true,
      step: 0,
      icon: "user",
    },

    {
      key: "phone_number",
      label: "Phone number",
      placeholder: "+91 XXXXXXXXXX",
      required: true,
      type: "tel",
      step: 0,
      icon: "phone",
      readOnlyFromRegistration: true,
    },

    {
      key: "district",
      label: "District",
      placeholder: "Select Maharashtra district",
      required: true,
      type: "select",
      step: 0,
      icon: "map",
      options: MAHARASHTRA_DISTRICTS.map(
        (item) => item.name
      ),
    },

    {
      key: "taluka",
      label: "Taluka",
      placeholder: "Select taluka",
      required: true,
      type: "dependent-select",
      dependsOn: "district",
      step: 0,
      icon: "map-pin",
      optionsByParent: MAHARASHTRA_TALUKAS,
    },

    {
      key: "village",
      label: "Village",
      placeholder: "Select/search village",
      required: true,
      type: "village-search",
      step: 0,
      icon: "landmark",
      wide: true,
    },

    {
      key: "profile_photo",
      label: "Profile photo",
      placeholder: "Paste a photo URL (optional)",
      required: false,
      type: "url",
      step: 0,
      icon: "camera",
      wide: true,
      hidden: true,
    },


    /* =====================================================
       STEP 2 — FARM & PRODUCTION

       Deliberately kept high-level. Lot-specific information
       belongs in Create Lot, not here.
    ====================================================== */

    {
      key: "land_size",
      label: "Farm / land size (hectares)",
      placeholder: "Select farm size",
      required: true,
      type: "select",
      step: 1,
      icon: "land",
      wide: true,
      options: [
        "Less than 0.5 hectare",
        "0.5 – 2 hectares",
        "2 – 5 hectares",
        "5 – 10 hectares",
        "10+ hectares",
      ],
    },

    {
      key: "cultivation_type",
      label: "Cultivation type",
      placeholder: "Select cultivation type",
      required: true,
      type: "select",
      step: 1,
      icon: "droplets",
      options: [
        "Irrigated",
        "Rainfed",
        "Both",
      ],
    },

    {
      key: "fpo_membership",
      label: "FPO / Cooperative association",
      placeholder: "Select",
      required: false,
      type: "select",
      step: 1,
      icon: "users",
      options: [
        "Yes",
        "No",
      ],
    },

    {
      key: "fpo_name",
      label: "FPO / Cooperative name",
      placeholder: "Enter FPO / cooperative name",
      required: false,
      step: 1,
      icon: "building",
      dependsOn: "fpo_membership",
    },

    {
      key: "storage_access",
      label: "Storage access",
      placeholder: "Select storage access",
      required: true,
      type: "select",
      step: 1,
      icon: "warehouse",
      options: [
        "Available",
        "Not Available",
      ],
    },

    {
      key: "storage_type",
      label: "Storage type",
      placeholder: "Select storage type",
      required: false,
      type: "select",
      step: 1,
      icon: "warehouse",
      options: [
        "Own",
        "FPO / Cooperative",
        "Private Warehouse",
      ],
      dependsOn: "storage_access",
    },

    {
      key: "crops_grown",
      label: "Crops / agricultural commodities grown",
      placeholder:
        "Select from one or more crop categories",
      required: true,
      type: "crop-multi-select",
      step: 1,
      icon: "sprout",
      wide: true,
      categories: FARMER_CROP_CATEGORIES,
    },

    {
      key: "about_farm",
      label: "About the farm",
      placeholder:
        "Briefly describe your farm in a sentence or two",
      required: false,
      type: "textarea",
      step: 1,
      icon: "file-text",
      maxLength: 200,
      wide: true,
      hidden: true,
    },
  ],


  tipIcon: "💡",

  tip:
    "Your farmer profile works like an agricultural resume. Other relevant AARTH participants can understand your farm background before interacting with your lots.",


  visualClass: "visual-farmer",

  visualImage: "/farmer-apmc-market.png",

  visualIcon: "🌾",

  visualLines: [
    "Maharashtra Farmers",
    "Better Market Linkages",
    "AARTH",
  ],


  quickIcon: "sprout",

  quickTitle:
    "Maharashtra-first farmer profile",

  quickText:
    "District, taluka, village and agricultural profile are structured around Maharashtra's administrative and market context.",
};


export default function FarmerDashboard() {
  return (
    <RoleProfileDashboard
      config={farmerConfig}
    />
  );
}
