import { authApi } from './auth';

const API_URL = (import.meta.env.VITE_API_URL || '').replace(/\/$/, '');

async function request(path, options = {}, authenticated = false) {
  const headers = { Accept: 'application/json', ...(options.body ? { 'Content-Type': 'application/json' } : {}) };
  if (authenticated) {
    const token = authApi.getSession()?.access_token;
    if (!token) throw new Error('Please log in to continue.');
    headers.Authorization = `Bearer ${token}`;
  }
  const response = await fetch(`${API_URL}${path}`, { ...options, headers });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.detail || 'Unable to complete this request.');
  return body;
}

const query = (params = {}) => new URLSearchParams(Object.entries(params).filter(([, value]) => value)).toString();

export const fpoApi = {
  list: (filters) => request(`/api/fpos?${query(filters)}`),
  detail: (id) => request(`/api/fpos/${id}`),
  claim: (id, data) => request(`/api/fpos/${id}/claim`, { method: 'POST', body: JSON.stringify(data) }, true),
  dashboard: () => request('/api/fpo/dashboard', {}, true),
  organisation: () => request('/api/fpo/organisation', {}, true),
  updateOrganisation: (data) => request('/api/fpo/organisation', { method: 'PATCH', body: JSON.stringify(data) }, true),
  members: () => request('/api/fpo/members', {}, true),
  invite: () => request('/api/fpo/members/invite', { method: 'POST' }, true),
  requestMembership: (invite_code) => request('/api/fpo/members/request', { method: 'POST', body: JSON.stringify({ invite_code }) }, true),
  decideMembership: (id, action) => request(`/api/fpo/members/${id}/${action}`, { method: 'PATCH' }, true),
  staff: () => request('/api/fpo/staff', {}, true),
  addStaff: (data) => request('/api/fpo/staff/invite', { method: 'POST', body: JSON.stringify(data) }, true),
};
