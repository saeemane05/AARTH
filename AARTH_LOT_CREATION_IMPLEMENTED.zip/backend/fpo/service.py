"""FPO operations backed exclusively by the combined public.fpos record."""
from __future__ import annotations

import secrets
from datetime import datetime, timezone
from typing import Any

from fastapi import HTTPException

from backend.auth.service import _client, profile_for_user

STAFF_ROLES = {'FPO_ADMIN', 'OPERATIONS_MANAGER', 'FIELD_COORDINATOR', 'FINANCE'}
MANAGE_ORG = {'FPO_ADMIN'}
MANAGE_MEMBERS = {'FPO_ADMIN', 'OPERATIONS_MANAGER'}
INVITE_FARMERS = {'FPO_ADMIN', 'FIELD_COORDINATOR'}


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def current_profile(token: str) -> dict[str, Any]:
    try:
        user = _client().auth.get_user(token).user
    except Exception as exc:
        raise HTTPException(401, 'Invalid session.') from exc
    profile = profile_for_user(user.id) if user else None
    if not profile or profile.get('status') != 'ACTIVE':
        raise HTTPException(401, 'Invalid session.')
    return profile


def get_fpo(fpo_id: str) -> dict[str, Any]:
    result = _client(admin=True).table('fpos').select('*').eq('id', fpo_id).maybe_single().execute()
    if not result.data:
        raise HTTPException(404, 'FPO not found.')
    return result.data


def public_fpo(row: dict[str, Any]) -> dict[str, Any]:
    source = row.get('source_data') or {}
    verification = row.get('verification_data') or {}
    return {
        'id': row['id'], 'fpo_name': row.get('fpo_name') or row.get('username') or 'Unnamed FPO',
        'organisation_type': row.get('organisation_type'), 'registration_number': row.get('registration_number'), 'district': row.get('district'),
        'taluka': row.get('taluka'), 'village': row.get('village'), 'address': row.get('address'),
        'crops': row.get('crops') or [], 'source': source.get('source'),
        'source_record_id': source.get('record_id'), 'source_last_updated': source.get('last_source_sync'),
        'verification_status': row.get('verification_status'), 'activation_status': row.get('activation_status'),
        'government_record_matched': bool(verification.get('government_record_matched')),
    }


def staff_role(row: dict[str, Any], user_id: str) -> str | None:
    if row.get('primary_admin_user_id') == user_id:
        return 'FPO_ADMIN'
    for member in row.get('staff_data') or []:
        if member.get('user_id') == user_id and member.get('status', 'ACTIVE') == 'ACTIVE':
            return member.get('role')
    return None


def authorised(row: dict[str, Any], user_id: str, allowed: set[str]) -> str:
    role = staff_role(row, user_id)
    if role not in allowed:
        raise HTTPException(403, 'You do not have permission for this FPO action.')
    return role


def update_fpo(fpo_id: str, patch: dict[str, Any]) -> dict[str, Any]:
    result = _client(admin=True).table('fpos').update(patch).eq('id', fpo_id).execute()
    return result.data[0]


def my_fpo(profile: dict[str, Any]) -> dict[str, Any]:
    admin = _client(admin=True)
    rows = admin.table('fpos').select('*').or_(f'primary_admin_user_id.eq.{profile["user_id"]},user_id.eq.{profile["user_id"]}').execute().data or []
    for row in rows:
        if staff_role(row, profile['user_id']):
            return row
    # JSONB staff entries are not expressible safely with the simple REST filter; scan FPOs for a staff assignment.
    for row in (admin.table('fpos').select('*').execute().data or []):
        if staff_role(row, profile['user_id']):
            return row
    raise HTTPException(404, 'No FPO organisation is assigned to this account.')


def membership_summary(row: dict[str, Any]) -> dict[str, int]:
    items = row.get('membership_data') or []
    return {'total': len(items), 'active': sum(x.get('status') == 'ACTIVE' for x in items),
            'pending': sum(x.get('status') == 'PENDING' for x in items),
            'inactive': sum(x.get('status') in {'LEFT', 'SUSPENDED', 'REJECTED'} for x in items)}


def membership_views(row: dict[str, Any]) -> list[dict[str, Any]]:
    result = []
    for membership in row.get('membership_data') or []:
        user_id = membership.get('farmer_user_id')
        profile = profile_for_user(user_id) if user_id else None
        if not profile or profile.get('role') != 'FARMER':
            continue
        data = profile.get('profile_data') or {}
        result.append({'membership_id': membership.get('id'), 'farmer_user_id': user_id,
            'aarth_id': profile.get('role_id') or profile.get('aarth_id'), 'full_name': data.get('full_name') or profile.get('username'),
            'district': data.get('district'), 'taluka': data.get('taluka'), 'village': data.get('village'),
            'crops': data.get('crops_grown') or [], 'land_size': data.get('land_size'),
            'status': membership.get('status'), 'requested_at': membership.get('requested_at'), 'approved_at': membership.get('approved_at')})
    return result


def invite(row: dict[str, Any], user_id: str) -> dict[str, Any]:
    authorised(row, user_id, INVITE_FARMERS)
    code = f"{''.join(ch for ch in (row.get('fpo_name') or 'AARTH').upper() if ch.isalnum())[:6]}-{secrets.token_hex(2).upper()}"
    entry = {'code': code, 'created_at': now(), 'created_by': user_id, 'status': 'ACTIVE'}
    invites = [*(row.get('invite_data') or []), entry]
    update_fpo(row['id'], {'invite_data': invites})
    return {**entry, 'fpo_id': row['id']}
