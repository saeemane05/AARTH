"""AARTH FPO foundation module."""
