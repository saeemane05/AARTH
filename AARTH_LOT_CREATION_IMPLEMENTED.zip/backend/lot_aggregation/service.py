from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from supabase import Client

from backend.database.models_sql.lot import quantity_to_kg
from backend.auth.service import _client, profile_for_user


def _lot_row(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": row.get("id"),
        "lot_id": row.get("lot_id"),
        "commodity_key": row.get("commodity_key"),
        "commodity_name": row.get("commodity_name"),
        "variety": row.get("variety"),
        "produce_form": row.get("produce_form"),
        "quantity": row.get("quantity"),
        "quantity_unit": row.get("quantity_unit"),
        "quantity_kg": row.get("quantity_kg"),
        "partial_sale_allowed": row.get("partial_sale_allowed"),
        "minimum_sale_quantity_kg": row.get("minimum_sale_quantity_kg"),
        "harvest_date": row.get("harvest_date"),
        "grade": row.get("grade"),
        "size_calibre": row.get("size_calibre"),
        "quality_measurements": row.get("quality_measurements") or {},
        "pickup_district": row.get("pickup_district"),
        "pickup_taluka": row.get("pickup_taluka"),
        "pickup_village": row.get("pickup_village"),
        "pickup_location_text": row.get("pickup_location_text"),
        "pickup_latitude": row.get("pickup_latitude"),
        "pickup_longitude": row.get("pickup_longitude"),
        "location_source": row.get("location_source"),
        "location_verified": row.get("location_verified"),
        "location_verified_at": row.get("location_verified_at"),
        "location_accuracy_m": row.get("location_accuracy_m"),
        "available_from": row.get("available_from"),
        "pickup_until": row.get("pickup_until"),
        "expected_price": row.get("expected_price"),
        "expected_price_unit": row.get("expected_price_unit"),
        "price_negotiable": row.get("price_negotiable"),
        "payment_needed_by": row.get("payment_needed_by"),
        "open_to_aggregation": row.get("open_to_aggregation"),
        "evidence": row.get("evidence") or [],
        "status": row.get("status"),
        "created_at": row.get("created_at"),
        "updated_at": row.get("updated_at"),
    }


def _get_farmer(user_id: str) -> dict[str, Any]:
    profile = profile_for_user(user_id)
    if not profile or profile.get("role") != "FARMER":
        raise ValueError("Only an active farmer account can manage farmer lots.")
    if profile.get("status") != "ACTIVE":
        raise ValueError("Farmer account is not active.")
    return profile


def _base_payload(payload, profile: dict[str, Any]) -> dict[str, Any]:
    quantity_kg = quantity_to_kg(payload.quantity, payload.quantity_unit)
    minimum_kg = None
    if payload.minimum_sale_quantity is not None:
        minimum_kg = quantity_to_kg(payload.minimum_sale_quantity, payload.quantity_unit)

    now = datetime.now(timezone.utc).isoformat()
    return {
        "profile_id": profile["id"],
        "user_id": profile["user_id"],
        "commodity_key": payload.commodity_key.strip(),
        "commodity_name": payload.commodity_name.strip(),
        "variety": (payload.variety or "").strip() or None,
        "produce_form": payload.produce_form.strip(),
        "quantity": payload.quantity,
        "quantity_unit": payload.quantity_unit,
        "quantity_kg": quantity_kg,
        "partial_sale_allowed": payload.partial_sale_allowed,
        "minimum_sale_quantity_kg": minimum_kg,
        "harvest_date": payload.harvest_date.isoformat(),
        "grade": (payload.grade or "").strip() or None,
        "size_calibre": (payload.size_calibre or "").strip() or None,
        "quality_measurements": payload.quality_measurements or {},
        "pickup_district": payload.pickup_district.strip(),
        "pickup_taluka": (payload.pickup_taluka or "").strip() or None,
        "pickup_village": payload.pickup_village.strip(),
        "pickup_location_text": payload.pickup_location_text.strip(),
        "pickup_latitude": payload.pickup_latitude,
        "pickup_longitude": payload.pickup_longitude,
        "location_source": payload.location_source,
        "location_verified": payload.location_verified,
        "location_verified_at": payload.location_verified_at or now,
        "location_accuracy_m": payload.location_accuracy_m,
        "available_from": payload.available_from.isoformat(),
        "pickup_until": payload.pickup_until.isoformat(),
        "expected_price": payload.expected_price,
        "expected_price_unit": payload.expected_price_unit,
        "price_negotiable": payload.price_negotiable,
        "payment_needed_by": payload.payment_needed_by.isoformat(),
        "open_to_aggregation": payload.open_to_aggregation,
        "evidence": payload.evidence or [],
        "status": payload.status,
    }


def create_lot(user_id: str, payload) -> dict[str, Any]:
    profile = _get_farmer(user_id)
    admin = _client(admin=True)
    data = _base_payload(payload, profile)
    result = admin.rpc("new_farmer_lot_id").execute()
    lot_id = result.data if result and result.data else None
    if not lot_id:
        raise ValueError("Could not generate a lot ID.")
    data["lot_id"] = lot_id
    response = admin.table("farmer_lots").insert(data).execute()
    if not response or not response.data:
        raise ValueError("Could not create the farmer lot.")
    return _lot_row(response.data[0])


def list_lots(user_id: str) -> list[dict[str, Any]]:
    _get_farmer(user_id)
    admin = _client(admin=True)
    response = (
        admin.table("farmer_lots")
        .select("*")
        .eq("user_id", user_id)
        .order("created_at", desc=True)
        .execute()
    )
    return [_lot_row(row) for row in (response.data or [])]


def get_lot(user_id: str, lot_id: str) -> dict[str, Any] | None:
    _get_farmer(user_id)
    admin = _client(admin=True)
    response = (
        admin.table("farmer_lots")
        .select("*")
        .eq("user_id", user_id)
        .eq("lot_id", lot_id)
        .maybe_single()
        .execute()
    )
    return _lot_row(response.data) if response and response.data else None


def summary(user_id: str) -> dict[str, Any]:
    lots = list_lots(user_id)
    return {
        "total": len(lots),
        "active": sum(l["status"] == "ACTIVE" for l in lots),
        "draft": sum(l["status"] == "DRAFT" for l in lots),
        "incomplete": any(l["status"] == "DRAFT" for l in lots),
    }
