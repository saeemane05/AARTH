from fastapi import APIRouter, Header, HTTPException

from backend.auth.service import _client
from .schema import LotCreateRequest, LotUpdateRequest
from .service import create_lot, get_lot, list_lots, summary

router = APIRouter(prefix="/api/lots", tags=["Farmer Lots"])


def _user_id(authorization: str) -> str:
    if not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="Invalid authorization header.")
    token = authorization[7:].strip()
    if not token:
        raise HTTPException(status_code=401, detail="Invalid session.")
    try:
        response = _client().auth.get_user(token)
        user = response.user if response else None
        if not user:
            raise ValueError()
        return user.id
    except Exception as exc:
        raise HTTPException(status_code=401, detail="Invalid session.") from exc


@router.get("")
def my_lots(authorization: str = Header(default="")):
    try:
        return {"lots": list_lots(_user_id(authorization))}
    except HTTPException:
        raise
    except ValueError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail="Could not load farmer lots.") from exc


@router.get("/summary")
def lots_summary(authorization: str = Header(default="")):
    try:
        return summary(_user_id(authorization))
    except HTTPException:
        raise
    except ValueError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail="Could not load lot status.") from exc


@router.get("/{lot_id}")
def lot_detail(lot_id: str, authorization: str = Header(default="")):
    try:
        lot = get_lot(_user_id(authorization), lot_id)
        if not lot:
            raise HTTPException(status_code=404, detail="Lot not found.")
        return lot
    except HTTPException:
        raise
    except ValueError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail="Could not load the lot.") from exc


@router.post("")
def create_farmer_lot(payload: LotCreateRequest, authorization: str = Header(default="")):
    try:
        return create_lot(_user_id(authorization), payload)
    except HTTPException:
        raise
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail="Could not create the farmer lot.") from exc
