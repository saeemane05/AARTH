import logging
import os

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from backend.auth.router import router as auth_router
from backend.fpo.router import router as fpo_router
from backend.location_services.router import router as location_router
from backend.lot_aggregation.router import router as lot_router


logging.basicConfig(
    level=logging.INFO
)


app = FastAPI(
    title="AARTH API"
)


frontend_url = os.getenv(
    "FRONTEND_URL",
    "",
).strip()


allowed_origins = [
    "http://localhost:5173",
    "http://127.0.0.1:5173",
    "http://localhost:3000",
    "http://127.0.0.1:3000",
]


if frontend_url:
    allowed_origins.append(
        frontend_url.rstrip("/")
    )


app.add_middleware(
    CORSMiddleware,

    allow_origins=allowed_origins,

    allow_credentials=True,

    allow_methods=["*"],

    allow_headers=["*"],
)


app.include_router(
    auth_router
)

app.include_router(fpo_router)
app.include_router(location_router)
app.include_router(lot_router)


@app.get("/")
async def root():
    return {
        "status":
            "AARTH API running"
    }


@app.get("/health")
async def health():
    return {
        "status": "healthy",
        "service": "AARTH API",
    }
