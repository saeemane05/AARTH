You are working on my existing project AARTH.

IMPORTANT:
AARTH is the final project name. Do NOT use SEVA anywhere in new UI, routes, components, database labels, comments, or user-facing text.

AARTH is being built for Smart India Hackathon 2026 for the Maharashtra Government problem statement:

"Strengthening market linkages and price discovery for farmers"

Organization:
Government of Maharashtra

Department:
Maharashtra State Innovation Society, Department of Skills, Employment, Entrepreneurship and Innovation

Theme:
Agriculture, FoodTech & Rural Development


============================================================
1. YOUR TASK
============================================================

Design and implement the COMPLETE FPO FOUNDATION MODULE of AARTH.

This is NOT just an FPO profile page.

The objective is to build the complete frontend + backend foundation for:

Government/public FPO data
        ↓
AARTH FPO master directory
        ↓
FPO discovery
        ↓
FPO claim/join process
        ↓
FPO representative verification
        ↓
FPO organisation activation
        ↓
FPO login
        ↓
FPO staff roles
        ↓
FPO organisation profile
        ↓
FPO dashboard
        ↓
FPO farmer network
        ↓
Farmer invitation / QR / registration code
        ↓
Farmer joins FPO
        ↓
FPO approves farmer
        ↓
Farmer becomes an active FPO member

STOP AT THIS STAGE.

Do NOT implement the later aggregation, buyer matching, negotiation, logistics transaction, payment, or dispute workflows yet.

Those will be built later on top of this foundation.


============================================================
2. VERY IMPORTANT PRODUCT PRINCIPLE
============================================================

Do NOT design AARTH around the assumption that every farmer must physically visit an FPO.

Farmers must be able to use AARTH independently.

The correct relationship is:

                    AARTH
                       |
          ---------------------------
          |                         |
       FARMER                       FPO
          |                         |
    Create/use own             Manage organisation
    AARTH account              and farmer network
          |
          |
     Farmer can discover
     relevant FPOs
          |
          ↓
    Optional FPO membership

FPO membership is OPTIONAL.

AARTH must NOT force:

Farmer → FPO → AARTH

Instead:

Farmer → AARTH

and FPO is one market/aggregation option available through AARTH.

The FPO becomes valuable because it can later aggregate farmer produce and create market access at scale.

Do not implement forced FPO membership.


============================================================
3. BUSINESS LOGIC WE HAVE DECIDED
============================================================

An FPO is NOT simply a registration centre.

The FPO is an aggregation organisation.

Its future value comes from:

- aggregating produce from multiple farmers
- creating larger lots
- accessing larger buyers
- coordinating collection
- coordinating grading
- coordinating logistics
- improving market access
- reducing individual transaction burden
- creating stronger bargaining/market linkage opportunities

Example:

Farmer A = 1.5 tonnes
Farmer B = 2 tonnes
Farmer C = 1 tonne
Farmer D = 3 tonnes

FPO can later aggregate:

7.5 tonnes

and create an aggregated market opportunity.

DO NOT implement the actual aggregation transaction now.

Only build the organisational/farmer-network foundation required for it.


============================================================
4. IMPORTANT ECONOMIC PRINCIPLE
============================================================

Do NOT hard-code a claim that AARTH guarantees farmers higher prices.

Do NOT say:

"Farmers will always get higher prices."

Instead AARTH should eventually provide:

- market visibility
- buyer options
- FPO aggregation options
- storage options
- logistics options
- offer comparison

The farmer remains the decision maker.

For this FPO module, simply build the infrastructure required for this future workflow.


============================================================
5. EXISTING AARTH PROJECT — DO NOT BREAK IT
============================================================

Before changing anything:

1. Inspect the existing repository.
2. Understand the current architecture.
3. Inspect existing authentication.
4. Inspect Supabase integration.
5. Inspect existing Farmer Dashboard.
6. Inspect existing Farmer Profile.
7. Inspect routing.
8. Inspect API structure.
9. Inspect database/schema structure.
10. Inspect existing UI components and design system.

DO NOT blindly rewrite the project.

DO NOT replace existing architecture.

DO NOT delete working code.

DO NOT break:

- authentication
- Supabase Auth
- registration
- login
- session handling
- role detection
- role-based redirects
- Farmer Dashboard
- Farmer Profile
- existing API calls
- existing backend functionality
- existing navigation
- existing responsive behaviour

Use the current project architecture and extend it.

If an existing component can be reused safely, reuse it.

If a new component is required, create a separate component.


============================================================
6. EXISTING FARMER DASHBOARD UI IS THE VISUAL REFERENCE
============================================================

The FPO dashboard must visually belong to the SAME AARTH product as the Farmer Dashboard.

IMPORTANT:

Use the Farmer Dashboard as the visual/design-system reference.

The following should remain conceptually consistent:

- navbar position
- navbar height
- AARTH logo placement
- navigation structure style
- search placement
- notification placement
- user profile placement
- page spacing
- card style
- border radius
- typography hierarchy
- shadows
- border treatment
- icon style
- button style
- section spacing
- page background
- responsive behaviour
- overall visual density

The FPO dashboard should feel like:

"the FPO version of the same AARTH application."

NOT like a completely different website.

However:

DO NOT copy the Farmer Dashboard content.

DO NOT copy farmer profile fields.

DO NOT copy farmer-specific cards.

DO NOT copy farmer-specific statistics.

DO NOT copy farmer-specific terminology.

DO NOT simply duplicate FarmerDashboard.jsx and rename it.

The visual system should be shared.

The information architecture must be different.


============================================================
7. FPO UI SHOULD HAVE ITS OWN INFORMATION ARCHITECTURE
============================================================

The FPO is an ORGANISATION.

Therefore the FPO UI should focus on:

- organisation
- staff
- farmer network
- membership
- crops represented
- organisation status
- verification
- future aggregation readiness
- market opportunities later

NOT:

- individual farm profile
- individual farm size
- individual cultivation type
- individual farmer readiness
- farmer personal information as the main dashboard

The FPO dashboard should look like an organisation management platform.


============================================================
8. FPO MODULE — FRONTEND ROUTES
============================================================

Create/extend routes approximately like:

PUBLIC:

/fpos
/fpos/:id

FPO ONBOARDING:

/fpo/claim/:id
/fpo/verification
/fpo/login

FPO APPLICATION:

/fpo/dashboard
/fpo/organisation
/fpo/farmers
/fpo/farmers/:id
/fpo/staff
/fpo/settings

Use the project's existing routing conventions.

Do not create duplicate routing systems.

If the project already has an appropriate routing structure, integrate into it.


============================================================
9. PUBLIC FPO DIRECTORY
============================================================

Create:

/fpos

Purpose:

Allow farmers/users to discover relevant FPOs.

UI should contain:

- page title
- search
- district filter
- taluka filter
- crop filter
- location/relevance information
- FPO cards
- verification/source badges
- distance where available
- FPO status

Example card:

-------------------------------------
Niphad Farmer Producer Company

📍 Niphad, Nashik

Onion • Grapes • Vegetables

3.8 km away

Government-listed
Source: SFAC

[ View FPO ]
[ Join FPO ]
-------------------------------------

For an organisation that has not claimed/activated its AARTH account:

SHOW:

"Government-listed"

or:

"Source matched"

DO NOT SHOW:

"AARTH Verified"

unless AARTH verification has actually been completed.


============================================================
10. FPO DETAIL PAGE
============================================================

Create:

/fpos/:id

Display:

- FPO name
- organisation type
- district
- taluka
- village/address where appropriate
- associated crops
- public organisation information
- source
- source freshness/date where available
- verification status
- AARTH activation status

Actions:

If unclaimed:

[ Claim / Join AARTH ]

For farmers:

[ Join FPO ]

If activated:

[ View FPO ]

[ Join FPO ]

Do not expose private information.


============================================================
11. FPO MASTER DATA
============================================================

IMPORTANT DATABASE DESIGN DECISION:

DO NOT create many separate FPO tables.

I do NOT want separate tables such as:

- fpo_master
- fpo_sources
- fpo_organisations
- fpo_staff
- fpo_memberships
- fpo_claims
- fpo_verifications
- fpo_invites

as independent database tables.

Keep the FPO foundation SIMPLE.

Use ONE COMBINED FPO TABLE for all FPO-related organisation, source, claim, verification, staff/admin, and membership information wherever practical.

The single table should be designed carefully with structured fields / JSONB fields where appropriate rather than creating unnecessary relational tables.

IMPORTANT:

Do NOT duplicate the existing farmer profile table.

The existing farmer profile/user system should continue to be used.

The one combined FPO table should contain the FPO organisation record and the data required to manage its current FPO state.

Conceptually, the combined table can contain appropriate fields such as:

id

fpo_name
organisation_type
registration_number

state
district
taluka
village
address

crops

source
source_record_id
source_last_updated

claim_status
verification_status
aarth_status

primary_admin_user_id

staff/users information where required
staff roles where required

membership information where required
membership status where required

claim information where required
verification information where required

invite information where required

created_at
updated_at

HOWEVER:

Do not blindly put everything into flat columns.

Where a field represents a collection or structured information, use appropriate JSON/JSONB structures if that is consistent with the existing PostgreSQL/Supabase architecture.

For example, staff roles, membership records, verification checkpoints, source mappings, and invite metadata may be represented as structured JSON/JSONB within the combined FPO record if appropriate.

The exact schema must be decided after inspecting the existing database.

The objective is:

ONE main FPO TABLE

rather than creating 8–10 separate FPO tables.

Use proper constraints, indexes, JSONB validation where appropriate, and clear relationships to existing users/farmer profiles.

Do not make the schema unnecessarily complicated.

IMPORTANT:

If the existing project already has an equivalent table that can be extended safely, use that instead of creating another table.

Do not create duplicate FPO data models.


============================================================
12. FPO DATA SOURCES
============================================================

The system should be designed to ingest/use government/public FPO information.

Relevant sources discussed for the architecture include:

- SFAC FPO data
- APEDA Farmer Connect FPO directory
- Maharashtra cooperative/government records where applicable
- other permitted official/public sources

IMPORTANT:

Do NOT claim that one source contains every FPO in Maharashtra.

Do NOT claim that the data is always live unless an actual live API/source integration exists.

Store or represent:

source
source_record_id
last_source_sync
last_verified
verification_status

within the combined FPO data model.

The UI should communicate the provenance of the record.

Example:

Government-listed
Source: SFAC
Last source update: [date]

Do not invent dates.

Do not invent FPO records.

Do not fabricate government verification.

If actual live source integration is not currently possible, build the ingestion interface/service architecture and seed the database using permitted/source-provided data.

Do not implement illegal scraping or bypass restrictions.


============================================================
13. FPO CLAIM WORKFLOW
============================================================

A government-listed FPO should not automatically become an AARTH account.

Correct workflow:

Government/public FPO record
        ↓
AARTH FPO master
        ↓
FPO appears in directory
        ↓
Authorised representative selects:
"Claim this organisation"
        ↓
Representative submits details
        ↓
Verification
        ↓
FPO activated
        ↓
FPO organisation account created

The claim, verification, activation and staff/admin state should be represented within the SINGLE combined FPO table rather than separate claim/verification/organisation tables.


============================================================
14. FPO CLAIM UI
============================================================

Route:

/fpo/claim/:id

Show existing FPO information as prefilled/read-only where appropriate.

Example:

FPO Name
Niphad Farmer Producer Company

Registration Number
XXXXXXXX

District
Nashik

Taluka
Niphad

Source
SFAC

Then claimant information:

Full Name *
Designation *
Mobile Number *
Official Email *

Designation options:

- CEO
- Managing Director
- Manager
- Authorised Representative
- Other

Checkbox:

"I confirm that I am authorised to represent this organisation."

Then:

[ Submit Claim ]

Do not ask the representative to re-enter information already available in the FPO master unless necessary.


============================================================
15. FPO VERIFICATION
============================================================

Use progressive verification.

Do NOT make the first onboarding screen require a huge set of documents.

The architecture should support verification layers:

Level 1:

- government/public record match
- organisation details match
- representative identity/contact verification

Later:

- registration document
- authority/appointment proof
- organisation documents
- applicable GST verification
- applicable e-NAM verification
- bank verification
- other applicable records

The UI must distinguish:

Government record matched

from:

AARTH Verified

from:

e-NAM registered

from:

AARTH transaction history

These are NOT the same thing.

Never display a generic "Government Certified" badge unless the underlying source actually certifies the organisation.


============================================================
16. FPO VERIFICATION UI
============================================================

Create a clear verification section.

Example:

VERIFICATION

✓ Government record matched
✓ Organisation details verified
✓ Representative verified

e-NAM registration
Not verified

GST
Not provided

AARTH activity
No transactions yet

Also provide:

[ View Verification Details ]

Show source and date where available.


============================================================
17. FPO ORGANISATION ACCOUNT
============================================================

Separate:

USER

from:

FPO ORGANISATION

Do not treat the FPO itself as just another personal user.

Architecture:

User
   ↓
FPO Staff Membership
   ↓
FPO Organisation

One FPO can have multiple staff users.

One user can have an organisation-specific role.

Because I want only ONE combined FPO database table, represent the organisation's staff/admin membership information inside that combined FPO record using a suitable structured field if appropriate.

Do NOT create a separate fpo_staff table unless repository inspection proves there is an existing unavoidable architectural requirement.


============================================================
18. FPO STAFF ROLES
============================================================

Implement organisation-level roles.

Minimum roles:

1. FPO_ADMIN

Usually CEO / Managing Director / authorised representative.

Permissions:

- manage organisation
- manage staff
- approve/reject farmer memberships
- view farmer network
- manage organisation profile
- access all current FPO functions

2. OPERATIONS_MANAGER

Permissions:

- view farmers
- manage farmer-related operational information where permitted
- manage future aggregation workflows
- view opportunities
- operational dashboard

3. FIELD_COORDINATOR

Permissions:

- onboard/invite farmers
- assist farmer registration
- view permitted farmer information
- coordinate field-level activities

4. FINANCE

Create the role architecture, but do not build the full payment/settlement system yet.

Permissions should be role-based.

Do not give every FPO staff member administrator privileges.

Staff records and roles should be represented within the SINGLE combined FPO table using a structured JSON/JSONB field where appropriate.

Do not create a separate fpo_staff table merely for this.


============================================================
19. FPO DATABASE STRUCTURE — SIMPLIFIED
============================================================

IMPORTANT:

I explicitly want a SIMPLE DATABASE DESIGN.

Do NOT create the following separate FPO tables:

fpo_master
fpo_sources
fpo_organisations
fpo_staff
fpo_memberships
fpo_claims
fpo_verifications
fpo_invites

Instead use:

EXISTING USER/AUTH TABLES
+
EXISTING FARMER PROFILE TABLE
+
ONE COMBINED FPO TABLE

The combined FPO table should be the central source of truth for FPO organisation data.

It can contain structured JSONB sections such as:

staff
membership_records
verification
sources
claims
invites

if required.

Example conceptual structure:

fpos

id
fpo_name
organisation_type
registration_number

location fields
crop fields

source_data JSONB

verification_data JSONB

claim_data JSONB

staff_data JSONB

membership_data JSONB

invite_data JSONB

primary_admin_user_id

activation_status
claim_status
verification_status

created_at
updated_at

This is only a conceptual example.

Do not blindly implement this exact schema.

Inspect the existing Supabase/PostgreSQL architecture first and design the simplest safe schema.

Use indexes where useful.

Avoid unnecessary relational complexity.

The system still needs to maintain proper logical relationships between:

FPO
Users
Farmers
Staff
Memberships

but do not create unnecessary tables just to represent those relationships.


============================================================
20. FPO MEMBERSHIP
============================================================

A farmer's AARTH identity and FPO membership must be separate logically.

However, because we are intentionally using ONE combined FPO table, membership records should be represented inside that FPO record in a structured form.

Conceptually:

FPO

membership_data:

[
  {
    farmer_user_id: "...",
    status: "ACTIVE",
    requested_at: "...",
    approved_at: "...",
    approved_by: "..."
  }
]

Possible statuses:

PENDING
ACTIVE
REJECTED
LEFT
SUSPENDED

Do NOT copy the farmer's entire profile into the FPO membership data.

The farmer owns their farmer profile.

The FPO owns the membership relationship.

If a farmer joins another FPO later, the system should be capable of representing multiple memberships over time.

Use the existing farmer/user ID as the reference instead of duplicating farmer data.


============================================================
21. FARMER JOINING — IMPORTANT
============================================================

Do NOT give farmers shared FPO credentials.

Farmers must always have their OWN AARTH account.

Correct flow:

FPO Dashboard
       ↓
Invite farmer
       ↓
QR / Invite Link / Registration Code
       ↓
Farmer
       ↓
Create AARTH account OR login
       ↓
Request FPO membership
       ↓
FPO approves
       ↓
Farmer becomes ACTIVE MEMBER


============================================================
22. FARMER DISCOVERS FPO
============================================================

A farmer should also be able to independently find an FPO.

Example:

Farmer dashboard
       ↓
Find FPO
       ↓
Location:
Niphad, Nashik
       ↓
Relevant nearby FPOs

Show:

distance
crops
verification status
organisation status
services where available

Do not automatically assign the farmer to an FPO.

Use wording:

"Nearby FPOs"

"Relevant FPOs"

"FPOs near you"

NOT:

"Your assigned FPO"

unless the farmer explicitly joins.


============================================================
23. FPO INVITE FARMER
============================================================

In:

/fpo/farmers

Add:

[ + Invite Farmer ]

Options:

[ Generate Invite Link ]

[ Generate QR Code ]

[ Generate Registration Code ]

Example:

NIPHAD-8X42

The invitation should point to a safe registration/join flow.

Do not expose sensitive organisation credentials.

Invite information should be represented within the combined FPO record in a structured field where appropriate.

Do not create a separate fpo_invites table.


============================================================
24. FARMER JOIN FLOW
============================================================

If farmer already has an AARTH account:

Login
   ↓
Join FPO request
   ↓
Pending
   ↓
FPO approval
   ↓
Active member

If farmer doesn't have an account:

Invite link
   ↓
Create AARTH account
   ↓
Farmer profile
   ↓
FPO membership request
   ↓
Pending
   ↓
FPO approval

Do not duplicate farmer accounts.


============================================================
25. FPO FARMER NETWORK DASHBOARD
============================================================

Route:

/fpo/farmers

The FPO should see:

Total Farmers
Active Farmers
Pending Requests
Inactive/Suspended

Search farmer

Filters:

- village
- crop
- membership status

Example:

FARMER NETWORK

42 Total Farmers
38 Active
4 Pending

--------------------------------

Yash Pawar
FAR-MH-000124

Niphad

Onion • Grapes

ACTIVE

[ View ]

--------------------------------

Rahul Shinde
FAR-MH-000125

Niphad

Onion

PENDING

[ Review ]

Do not show excessive private farmer information.

Follow least-privilege principles.


============================================================
26. FARMER DETAILS FROM FPO SIDE
============================================================

When FPO clicks a farmer:

Show only information relevant to FPO operations and permitted by the data model.

Example:

Yash Pawar

AARTH ID:
FAR-MH-000124

Location:
Niphad, Nashik

Farm Size:
2.5 acres

Crops:
Onion
Grapes

FPO Membership:
Active

Joined:
[date]

Do NOT create a second farmer profile owned by the FPO.


============================================================
27. FPO DASHBOARD UI
============================================================

Create:

/fpo/dashboard

The dashboard should feel like an organisation management system.

Example structure:

AARTH

Home
Organisation
Farmers
Aggregation
Market Opportunities
Transactions
Logistics
Reports

Search
Notifications
FPO Admin

--------------------------------------------

Good morning, Niphad FPO

Government-listed ✓
AARTH Verified ✓

--------------------------------------------

SUMMARY CARDS

Members
482

Active Farmers
391

Crops
5

Pending Requests
4

--------------------------------------------

FARMER NETWORK

Onion       24
Grapes      12
Vegetables   6

--------------------------------------------

PENDING ACTIONS

4 farmer registration requests

[ Review ]

--------------------------------------------

ORGANISATION

Niphad
Nashik
Maharashtra

[ Manage Organisation ]


============================================================
28. FUTURE MODULES SHOULD BE VISIBLE BUT NOT IMPLEMENTED
============================================================

The FPO navigation can contain:

Home
Organisation
Farmers
Aggregation
Market Opportunities
Transactions
Logistics
Reports

But only implement the foundation needed now.

For future modules you may show:

Coming Soon

or disabled navigation.

Do not implement fake transaction data.

Do not create fake offers.

Do not create fake buyer transactions just to make the dashboard look full.

Use empty states where actual data does not yet exist.

Example:

"No active aggregation lots yet."

This is better than fabricated data.


============================================================
29. FPO ORGANISATION PROFILE
============================================================

Route:

/fpo/organisation

Display:

Organisation name
Organisation type
Registration number
District
Taluka
Village/address
Associated crops
Storage availability if legitimately part of FPO data
Verification information
Primary administrator
AARTH status

Do NOT copy the Farmer Profile.

The farmer profile is an individual agricultural profile.

The FPO profile is an organisation profile.


============================================================
30. FRONTEND COMPONENT STRUCTURE
============================================================

Follow the existing project structure.

If appropriate, create components such as:

FPOLayout
FPONavbar
FPODashboard
FPOOrganisationProfile
FPODirectory
FPOCard
FPOClaimForm
FPOVerification
FPOStaffManagement
FPOFarmers
FPOMemberCard
FPOMembershipRequest
FPOInviteDialog
FPOQRCode
FPOEmptyState
FPOStatusBadge

Reuse existing AARTH UI primitives wherever possible.

Do not create an entirely separate design system.


============================================================
31. BACKEND API
============================================================

Implement clean FastAPI endpoints according to existing backend conventions.

Potential endpoints:

GET /api/fpos
GET /api/fpos/{id}

GET /api/fpos/nearby
GET /api/fpos/search

POST /api/fpos/{id}/claim

GET /api/fpo/claims
GET /api/fpo/claims/{id}

POST /api/fpo/claims/{id}/verify

GET /api/fpo/me
GET /api/fpo/dashboard

GET /api/fpo/members
POST /api/fpo/members/invite
POST /api/fpo/members/request
PATCH /api/fpo/members/{id}/approve
PATCH /api/fpo/members/{id}/reject

GET /api/fpo/staff
POST /api/fpo/staff/invite
PATCH /api/fpo/staff/{id}/role

GET /api/fpo/organisation
PATCH /api/fpo/organisation

Adapt these to the existing backend conventions rather than blindly creating these exact URLs.

Because we are using ONE combined FPO table, endpoints may internally read/update different structured fields of the same FPO record.

Do not create separate database tables simply because the API endpoints are logically separate.


============================================================
32. AUTHORIZATION
============================================================

Authentication:

Continue using the existing authentication system.

Authorization:

Use role + organisation membership.

Example:

FARMER
→ Farmer routes

FPO_ADMIN
→ FPO organisation management

OPERATIONS_MANAGER
→ permitted FPO operational routes

FIELD_COORDINATOR
→ permitted farmer onboarding routes

FINANCE
→ future finance routes

A user should NOT gain access merely because they know a URL.

Backend must enforce permissions.

Frontend hiding buttons is NOT sufficient.


============================================================
33. SECURITY
============================================================

Use proper authorization.

Do not expose:

- private farmer information
- organisation credentials
- private verification documents
- bank information
- authentication secrets

Use existing Supabase RLS architecture if applicable.

Do not put secrets in frontend code.

Do not hard-code API keys.

Do not weaken existing security/RLS.

Because staff and membership data are stored in the combined FPO record, make sure backend authorization carefully checks the requesting user's relationship to that FPO before reading/updating those fields.


============================================================
34. DATA MODEL RELATIONSHIPS
============================================================

The final conceptual relationship should be:

USER

|

+---- FARMER PROFILE

|

+---- FPO STAFF MEMBERSHIP

|

↓

FPO ORGANISATION

|

↓

FPO MASTER DATA

|

↓

EXTERNAL SOURCES

And:

FARMER USER

|

↓

FPO MEMBERSHIP

|

↓

FPO ORGANISATION

One farmer can potentially have multiple FPO memberships over time.

One FPO can have many farmers.

One FPO can have multiple staff users.

IMPORTANT:

These are LOGICAL relationships.

Do NOT create a separate database table for every relationship.

The implementation should use the ONE combined FPO table wherever practical and use existing user/farmer tables rather than duplicating those records.


============================================================
35. LOCATION LOGIC
============================================================

AARTH is Maharashtra-first.

Use the existing Maharashtra location master already present in the project.

Respect the existing:

- district
- taluka
- village

hierarchy.

Do not hard-code tens of thousands of villages into the frontend.

Use the existing searchable village architecture.

FPO discovery should eventually use location information to identify nearby/relevant FPOs.

Do not invent coordinates.

If exact coordinates are unavailable, use the available administrative location and clearly handle the limitation.


============================================================
36. UI DESIGN RULES
============================================================

The FPO UI must be:

- professional
- clean
- modern
- agriculture-focused
- Maharashtra-first
- enterprise-grade
- easy for non-technical FPO staff
- responsive
- desktop + mobile friendly

Visual language should match Farmer Dashboard.

Use:

- same navbar position
- same card treatment
- same spacing system
- same typography
- same button hierarchy
- same AARTH brand language

But change the CONTENT and INFORMATION ARCHITECTURE.

Do NOT simply copy:

Farmer Profile

Farm Size

Cultivation Type

Farmer readiness

Farmer-specific quick information

etc.

The FPO dashboard should instead communicate:

Organisation

Members

Staff

Verification

Farmer network

Membership requests

Organisation activity

Future aggregation readiness


============================================================
37. EMPTY STATES
============================================================

Since this module is being built incrementally, handle empty states professionally.

Examples:

"No farmer members yet."

"Your FPO has no pending membership requests."

"No staff members have been added."

"No aggregation lots yet."

"No active market opportunities yet."

Do not fill these areas with fake statistics.


============================================================
38. DEMO / SEED DATA
============================================================

If seed/demo data is needed for development:

Clearly separate demo data from production data.

Use realistic Maharashtra examples only for development.

DO NOT represent fabricated organisations as government verified.

If demo records are used, label them:

"Demo"

or keep them in a development-only seed.

Do not fabricate official verification.


============================================================
39. FARMER DASHBOARD COMPATIBILITY
============================================================

This is extremely important.

The existing Farmer Dashboard must continue to work exactly as before.

Do not modify its core workflow unnecessarily.

The FPO module should integrate with the Farmer Dashboard through navigation and APIs.

For example, a farmer may eventually have:

Farmer Dashboard

↓

Find FPOs

↓

FPO Directory

↓

Join FPO

But the farmer dashboard itself should not be redesigned unless absolutely necessary.


============================================================
40. DO NOT IMPLEMENT THESE YET
============================================================

Explicitly DO NOT implement:

- aggregated lot creation
- buyer matching
- buyer requirements
- offer comparison
- negotiation
- transaction booking
- logistics booking
- payment settlement
- dispute management
- reputation scoring
- AI recommendation engine
- complex FPO financial management

Only create the architecture/hooks required for these future modules.


============================================================
41. EXPECTED END-TO-END DEMO
============================================================

After implementation, I should be able to demonstrate this exact flow:

SCENARIO:

1. Government/public FPO data exists in AARTH master database.

2. Farmer opens:
/fpos

3. Farmer searches:
Nashik → Niphad → Onion

4. Farmer sees relevant FPO.

5. Farmer opens FPO profile.

6. FPO is shown as:
Government-listed
Source: [actual source]

7. An authorised representative claims the FPO.

8. Representative enters:
name
designation
mobile
email

9. Verification workflow is triggered.

10. FPO becomes AARTH-activated only after appropriate verification.

11. FPO representative logs in.

12. FPO is redirected to:
/fpo/dashboard

13. Dashboard shows:
organisation information
farmer count
active members
pending requests
crops represented
verification status

14. FPO admin adds/invites staff.

15. FPO admin opens:
Farmers

16. FPO generates:
QR / invite link / registration code

17. Farmer scans the QR or opens invite link.

18. Farmer creates an AARTH account or logs in.

19. Farmer sees:
"Join Niphad FPO"

20. Farmer submits membership request.

21. FPO dashboard shows:
"New farmer membership request"

22. FPO admin approves.

23. Farmer becomes:
ACTIVE MEMBER

24. Farmer appears in FPO's farmer network.

25. Farmer still retains their own AARTH account and Farmer Dashboard.

26. FPO retains its own organisation dashboard.

This is the COMPLETE acceptance flow for this development phase.


============================================================
42. IMPORTANT BUSINESS PRINCIPLE
============================================================

AARTH should NOT make the FPO a mandatory middleman.

The future AARTH market flow should support:

Farmer → Direct Buyer

OR

Farmer → FPO → Buyer

OR

Farmer → Storage → Buyer

The farmer should be able to compare economically relevant options.

The FPO earns value from services and aggregation/business operations, not simply from having a farmer registered.

Do not build a system where FPO membership is the only route to selling produce.


============================================================
43. WHAT I EXPECT FROM YOU BEFORE CODING
============================================================

FIRST:

Inspect the existing repository.

Identify:

- frontend structure
- backend structure
- existing auth
- existing Farmer Dashboard
- existing Farmer Profile
- existing Supabase schema
- existing role handling
- existing routing
- existing reusable UI components
- existing API services
- existing database tables that may already represent users/farmers/FPOs

Then give me a short implementation plan based on the ACTUAL repository.

Specifically explain:

1. Which existing tables/components will be reused.
2. Which ONE combined FPO table will be created or extended.
3. What structured fields/JSONB sections will be used inside that table.
4. How users/farmers will be referenced without duplicating their data.
5. What frontend routes/components will be added.
6. What backend APIs will be added.
7. How authorization will work.

Do NOT immediately rewrite files.

After the plan, implement the FPO foundation incrementally.


============================================================
44. IMPLEMENTATION RULES
============================================================

IMPORTANT:

- Do not delete working functionality.
- Do not replace the existing Farmer Dashboard.
- Do not replace React with React Native.
- Do not replace FastAPI.
- Do not replace Supabase.
- Do not introduce an unnecessary new framework.
- Do not create duplicate authentication.
- Do not duplicate farmer profiles.
- Do not create unnecessary FPO tables.
- Do not create separate fpo_master/fpo_sources/fpo_organisations/fpo_staff/fpo_memberships/fpo_claims/fpo_verifications/fpo_invites tables.
- Use ONE combined FPO table as the central FPO data model.
- Use structured JSON/JSONB fields where appropriate.
- Do not hard-code fake government verification.
- Do not fabricate government data.
- Do not create fake transactions.
- Do not hard-code thousands of villages.
- Do not put secrets in frontend.
- Do not weaken existing security/RLS.
- Do not break current routes.

Prefer incremental changes.


============================================================
45. FINAL TECHNICAL OBJECTIVE
============================================================

When you finish this phase, AARTH should have two clearly different but visually consistent experiences:

FARMER:

AARTH

↓

Farmer Login

↓

Farmer Dashboard

↓

Farmer Profile

↓

Find FPO

↓

Join FPO (optional)


FPO:

AARTH

↓

FPO Claim / Login

↓

Organisation Verification

↓

FPO Dashboard

↓

Organisation Profile

↓

Staff Management

↓

Farmer Network

↓

Invite / QR / Registration Code

↓

Farmer Membership Requests

↓

Approve Farmer

↓

Active FPO Members


The next future layer will then be:

FPO Members

↓

Produce aggregation

↓

Aggregated lots

↓

Buyer matching

↓

Offers

↓

Transaction

↓

Logistics

↓

Settlement

DO NOT implement that future layer now.


============================================================
46. QUALITY BAR
============================================================

This is for SIH 2026.

Do not build a superficial "FPO CRUD page."

Build a coherent foundation that can realistically evolve into AARTH's FPO aggregation and market-linkage system.

The implementation must have:

- clean architecture
- simple database design
- ONE combined FPO table
- proper structured FPO data
- proper role permissions
- proper authentication integration
- proper organisation membership
- source-aware FPO master data
- claim workflow
- verification states
- farmer membership workflow
- invite/QR workflow
- responsive UI
- consistent AARTH design
- proper empty/loading/error states
- no fake claims

Most importantly:

The frontend and backend must represent the SAME business model.

Do not create UI features that the backend cannot support.

Do not create backend structures that the frontend cannot use.

Do not add database tables unless they are genuinely necessary after inspecting the existing schema.

Keep the FPO data architecture simple enough to maintain for the SIH project, while still allowing the future aggregation/market-linkage modules to be built on top of it.


============================================================
47. AFTER IMPLEMENTATION
============================================================

Provide:

1. Files created
2. Files modified
3. Database tables/migrations added
4. Exact structure of the ONE combined FPO table
5. JSON/JSONB fields used inside it and what each contains
6. API endpoints added
7. Authentication/authorization changes
8. Frontend routes added
9. FPO roles and permissions
10. FPO claim workflow
11. Farmer membership workflow
12. Invite/QR workflow
13. Any assumptions made
14. Any parts that still require real government/API integration
15. Exact commands required to run migrations/backend/frontend
16. A manual end-to-end test checklist

Do not claim something is implemented if it is only mocked.

Clearly separate:

IMPLEMENTED

MOCKED FOR DEVELOPMENT

REQUIRES REAL EXTERNAL DATA/API

FUTURE MODULE


============================================================
FINAL INSTRUCTION
============================================================

Do not optimize for number of files or number of database tables.

Optimize for:

Simplicity
Correctness
Maintainability
Security
Clear organisation/farmer relationships
SIH demonstration readiness
Future extensibility

The single most important database requirement is:

ONE COMBINED FPO TABLE.

Do not create 8–10 separate FPO tables unless you first prove from the existing repository that a separate table is technically unavoidable.

First inspect the repository.
Then explain the implementation plan.
Then implement incrementally.